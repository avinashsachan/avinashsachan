/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ssh_test2;

import com.ScriptingSSH.ScriptingSSH;

/**
 *
 * @author a182kuma
 */
public class Ssh_test2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        ScriptingSSH sh = new ScriptingSSH("192.168.44.129", 22, "v49singh", "server@123", "rtr1");
        try {

            System.out.println("Connection State : " + sh.connect());
            Thread.sleep(100);
            sh.clearSessionLog();
            int i = sh.sendAndWait("/sbin/ifconfig", "eth3#eth6#eth7", "#");
            System.out.println("Found " + i);
            sh.clearSessionLog();

            sh.sendAndWait("su - avinash", "Password");
            System.out.println(sh.getSessionLog());
            sh.clearSessionLog();
            sh.sendAndWait("testuser", "avinash@server2");
            System.out.println(sh.getSessionLog());
            sh.clearSessionLog();
            sh.sendAndWait("pwd", "avinash@server2");
            System.out.println(sh.getSessionLog());
            sh.clearSessionLog();


            //  Thread.sleep(1000);
            //  System.out.println("Found " + i);
            System.out.println(sh.getSessionLog());

            System.out.println("Disconnection State : " + sh.disconnect());
            Thread.sleep(100);
            System.out.println("");

        } catch (Exception ex) {
            System.err.println(ex.getMessage());
        } finally {
            sh.disconnect();
        }

    }
}
